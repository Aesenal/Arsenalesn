chmod +x easysploit
cp -r easysploit /usr/local/sbin
echo "rm -rf /usr/local/sbin/easysploit && echo -e '\e[1;31m    

                       (UNINSTALLATION COMPLETED)

\e[0m' && rm uninstaller.sh " > uninstaller.sh 



echo -e '\e[1;33m
     ______                 _____       __      _ __ 
    / ____/___ ________  __/ ___/____  / /___  (_) /_
   / __/ / __ `/ ___/ / / /\__ \/ __ \/ / __ \/ / __/
  / /___/ /_/ (__  ) /_/ /___/ / /_/ / / /_/ / / /_   v4.2
 /_____/\__,_/____/\__, //____/ .___/_/\____/_/\__/  (Linux)
                  /____/     /_/                        \e[1;34m
                                
                                Created by "KALI LINUX TRICKS"
                                https://www.youtube.com/c/KALILINUXTRICKS\e[1;31m


  Usage of EASYSPLOIT for attacking targets without prior mutual consent is
  ILLEGAL. Developers are not responsible for any damage caused by this script.
  EASYSPLOIT is intented ONLY FOR EDUCATIONAL PURPOSES!!! STAY LEGAL!!!

\e[1;36m
                      
                       (INSTALLATION COMPLETED)

                                                             \e[1;32m

  To execute EasySploit type anywhere in your terminal "easysploit".  \e[0m 
'















 
